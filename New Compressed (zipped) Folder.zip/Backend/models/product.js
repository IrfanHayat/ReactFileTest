// models/Product.js
const { DataTypes } = require("sequelize");
const sequelize = require("../database/db"); // Adjust the path accordingly

const Product = sequelize.define(
  "Product",
  {
    product_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    product_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    category_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    tableName: "products", // Ensure correct table name
    // timestamps: true, // Adjust as needed based on your table
  }
);

module.exports = Product;
