// models/Category.js
const { DataTypes } = require("sequelize");
const sequelize = require("../database/db");

const Category = sequelize.define(
  "Category",
  {
    category_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    category_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    tableName: "categories", // Ensure correct table name
    // Adjust as needed based on your table
  }
);

module.exports = Category;
