const { DataTypes } = require("sequelize");
const sequelize = require("../database/db"); // Adjust the path accordingly

const Item = sequelize.define(
  "Item",
  {
    item_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    item_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    product_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    tableName: "items", // Ensure correct table name
    // timestamps: true, // Adjust as needed based on your table
  }
);

module.exports = Item;
