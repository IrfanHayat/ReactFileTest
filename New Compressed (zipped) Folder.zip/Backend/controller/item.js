// controllers/itemController.js
const Item = require("../models/item");

const itemController = {
  getAllItems: async (req, res) => {
    try {
      const { page = 1, pageSize = 20 } = req.query;
      const offset = (page - 1) * pageSize;

      const items = await Item.findAll({
        limit: pageSize,
        offset: offset,
      });

      res.json(items);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },

  getItemById: async (req, res) => {
    const { id } = req.params;
    try {
      const item = await Item.findByPk(id);
      if (!item) {
        return res.status(404).json({ error: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },

  createItem: async (req, res) => {
    const { item_name, product_id } = req.body;
    try {
      const newItem = await Item.create({ item_name, product_id });
      res.json(newItem);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },

  updateItem: async (req, res) => {
    const { id } = req.params;
    const { item_name, product_id } = req.body;
    try {
      const item = await Item.findByPk(id);
      if (!item) {
        return res.status(404).json({ error: "Item not found" });
      }
      await item.update({ item_name, product_id });
      res.json(item);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },

  deleteItem: async (req, res) => {
    const { id } = req.params;
    try {
      const item = await Item.findByPk(id);
      if (!item) {
        return res.status(404).json({ error: "Item not found" });
      }
      await item.destroy();
      res.json({ message: "Item deleted successfully" });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },
};

module.exports = itemController;
