const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const categoryRoutes = require("./routes/category");
const productRoutes = require("./routes/products");
const itemRoutes = require("./routes/item");
const sequelize = require("./database/db"); // Import Sequelize connection

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

// Apply Sequelize synchronization to create tables
sequelize
  .sync()
  .then(() => {
    console.log("Database synchronized");
  })
  .catch((error) => {
    console.error("Error synchronizing database:", error);
  });

app.use("/api/categories", categoryRoutes);
app.use("/api/products", productRoutes);
app.use("/api/items", itemRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
