// db.js
const { Sequelize } = require("sequelize");

const sequelize = new Sequelize("inventory", "root", "root", {
  host: "localhost",
  dialect: "mysql",
  define: {
    timestamps: false, // Disable timestamps for each model
  },
});

module.exports = sequelize;
