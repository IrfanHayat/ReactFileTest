// store/index.js

import { createStore, applyMiddleware } from "redux";
import { thunk } from "redux-thunk"; // Import specific named exports

import rootReducer from "../reducers/inventoryReducer";

const store = createStore(
  rootReducer,
  applyMiddleware(thunk) // Use the default export if available
);

export default store;
