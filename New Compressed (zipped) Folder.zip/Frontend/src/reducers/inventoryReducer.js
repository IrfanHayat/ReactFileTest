const initialState = {
  inventory: [],
};

const inventoryReducer = (state = initialState, action) => {
  switch (action.type) {
    case "FETCH_INVENTORY_SUCCESS":
      return { ...state, inventory: action.payload };
    case "ADD_INVENTORY_SUCCESS":
      return { ...state, inventory: [...state.inventory, action.payload] };
    case "UPDATE_INVENTORY_SUCCESS":
      const updatedInventory = state.inventory.map((item) =>
        item.id === action.payload.id ? action.payload : item
      );
      return { ...state, inventory: updatedInventory };
    case "DELETE_INVENTORY_SUCCESS":
      const filteredInventory = state.inventory.filter(
        (item) => item.id !== action.payload
      );
      return { ...state, inventory: filteredInventory };
    default:
      return state;
  }
};

export default inventoryReducer;
