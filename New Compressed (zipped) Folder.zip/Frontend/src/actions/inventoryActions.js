import axios from "axios";

const API_BASE_URL = "http://localhost:5000/api"; // Adjust this URL according to your backend

export const fetchInventory = () => async (dispatch) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/items`);
    dispatch({ type: "FETCH_INVENTORY_SUCCESS", payload: response.data });
  } catch (error) {
    console.error("Error fetching inventory:", error);
  }
};

export const addInventory = (newItem) => async (dispatch) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/items`, newItem);
    dispatch({ type: "ADD_INVENTORY_SUCCESS", payload: response.data });
  } catch (error) {
    console.error("Error adding inventory:", error);
  }
};

export const updateInventory = (itemId, updatedItem) => async (dispatch) => {
  try {
    const response = await axios.put(
      `${API_BASE_URL}/items/${itemId}`,
      updatedItem
    );
    dispatch({ type: "UPDATE_INVENTORY_SUCCESS", payload: response.data });
  } catch (error) {
    console.error("Error updating inventory:", error);
  }
};

export const deleteInventory = (itemId) => async (dispatch) => {
  try {
    await axios.delete(`${API_BASE_URL}/items/${itemId}`);
    dispatch({ type: "DELETE_INVENTORY_SUCCESS", payload: itemId });
  } catch (error) {
    console.error("Error deleting inventory:", error);
  }
};
