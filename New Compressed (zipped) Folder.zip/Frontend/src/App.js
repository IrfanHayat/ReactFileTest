import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchInventory } from "./actions/inventoryActions";
import InventoryForm from "./components/inventoryForm";
import InventoryList from "./components/inventoryList";

function App() {
  const dispatch = useDispatch();
  const inventory = useSelector((state) => state.inventory);

  useEffect(() => {
    dispatch(fetchInventory());
  }, [dispatch]);

  return (
    <div>
      <h1>Inventory App</h1>
      <InventoryForm />
      <InventoryList inventory={inventory} />
    </div>
  );
}

export default App;
