import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { deleteInventory, updateInventory } from "../actions/inventoryActions";
import styled from "styled-components";

const InventoryContainer = styled.div`
  padding: 20px;
  background-color: #f5f5f5;
`;

const InventoryItem = styled.li`
  list-style-type: none;
  background-color: #fff;
  margin: 10px 0;
  padding: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;

  button {
    margin-left: 10px;
    cursor: pointer;
    background-color: #3498db;
    color: #fff;
    border: none;
    padding: 5px 10px;
    border-radius: 5px;
  }
`;

const Modal = styled.div`
  display: ${({ showModal }) => (showModal ? "block" : "none")};
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.5);
`;

const ModalContent = styled.div`
  background-color: #fefefe;
  margin: 15% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 60%;

  h3 {
    color: #333;
  }

  input {
    width: 100%;
    padding: 8px;
    margin: 8px 0;
    box-sizing: border-box;
  }

  button {
    background-color: #4caf50;
    color: #fff;
    border: none;
    padding: 10px;
    border-radius: 5px;
    cursor: pointer;
  }
`;

const InventoryList = ({ inventory }) => {
  const dispatch = useDispatch();
  const [showModal, setShowModal] = useState(false);
  const [updatedItemName, setUpdatedItemName] = useState("");
  const [selectedItemId, setSelectedItemId] = useState(null);

  const handleDelete = (itemId) => {
    dispatch(deleteInventory(itemId));
  };

  const handleUpdate = (itemId) => {
    setShowModal(true);
    setSelectedItemId(itemId);
    // You can also pre-fill the input with the existing item name
    // const selectedItem = inventory.find((item) => item.item_id === itemId);
    // setUpdatedItemName(selectedItem.item_name);
  };

  const handleModalClose = () => {
    setShowModal(false);
    setSelectedItemId(null);
    setUpdatedItemName("");
  };

  const handleUpdateConfirm = () => {
    dispatch(updateInventory(selectedItemId, { item_name: updatedItemName }));
    handleModalClose();
  };

  return (
    <InventoryContainer>
      <h2>Inventory List</h2>
      <ul>
        {inventory.map((item) => (
          <InventoryItem key={item.id}>
            <span>
              {item.item_name} - {item.product_id}
            </span>
            <div>
              <button onClick={() => handleDelete(item.item_id)}>Delete</button>
              <button onClick={() => handleUpdate(item.item_id)}>Update</button>
            </div>
          </InventoryItem>
        ))}
      </ul>

      <Modal showModal={showModal}>
        <ModalContent>
          <span onClick={handleModalClose}>&times;</span>
          <h3>Update Item Name</h3>
          <input
            type="text"
            value={updatedItemName}
            onChange={(e) => setUpdatedItemName(e.target.value)}
          />
          <button onClick={handleUpdateConfirm}>Update</button>
        </ModalContent>
      </Modal>
    </InventoryContainer>
  );
};

export default InventoryList;
