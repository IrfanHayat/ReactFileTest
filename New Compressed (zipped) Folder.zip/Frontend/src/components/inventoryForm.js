import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addInventory } from "../actions/inventoryActions";
import styled from "styled-components";

const FormContainer = styled.div`
  margin: 20px;
  padding: 20px;
  background-color: #f5f5f5;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
`;

const FormTitle = styled.h2`
  color: #333;
  margin-bottom: 20px;
`;

const StyledForm = styled.form`
  display: flex;
  flex-direction: column;

  label {
    margin-bottom: 10px;
    color: #555;
  }

  input {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  button {
    padding: 10px;
    background-color: #3498db;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
`;

const InventoryForm = () => {
  const dispatch = useDispatch();
  const [newItem, setNewItem] = useState({ item_name: "", product_id: "" });

  const handleChange = (e) => {
    setNewItem({ ...newItem, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addInventory(newItem));
    setNewItem({ item_name: "", product_id: "" });
  };

  return (
    <FormContainer>
      <FormTitle>Add New Inventory</FormTitle>
      <StyledForm onSubmit={handleSubmit}>
        <label>
          Item Name:
          <input
            type="text"
            name="item_name"
            value={newItem.item_name}
            onChange={handleChange}
          />
        </label>
        <label>
          Product ID:
          <input
            type="text"
            name="product_id"
            value={newItem.product_id}
            onChange={handleChange}
          />
        </label>
        <button type="submit">Add Inventory</button>
      </StyledForm>
    </FormContainer>
  );
};

export default InventoryForm;
